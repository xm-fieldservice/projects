import win32gui
import win32con
import win32api
import win32clipboard
import pyperclip
import time

class InjectionService:
    def __init__(self, logger):
        self.logger = logger
    
    def inject_command(self, command, target_window, target_position):
        try:
            # 激活目标窗口
            hwnd = win32gui.FindWindow(None, target_window)
            if hwnd == 0:
                return False, "找不到目标窗口"
            
            win32gui.SetForegroundWindow(hwnd)
            time.sleep(0.5)
            
            # 移动鼠标到目标位置
            x, y = target_position
            win32api.SetCursorPos((x, y))
            time.sleep(0.1)
            
            # 点击目标位置
            win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0)
            time.sleep(0.1)
            win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP, 0, 0, 0, 0)
            time.sleep(0.1)
            
            # 将命令复制到剪贴板（使用pyperclip支持Unicode字符）
            pyperclip.copy(command)
            
            # 模拟Ctrl+V粘贴
            win32api.keybd_event(win32con.VK_CONTROL, 0, 0, 0)
            win32api.keybd_event(ord('V'), 0, 0, 0)
            time.sleep(0.1)
            win32api.keybd_event(ord('V'), 0, win32con.KEYEVENTF_KEYUP, 0)
            win32api.keybd_event(win32con.VK_CONTROL, 0, win32con.KEYEVENTF_KEYUP, 0)
            
            # 模拟回车键
            win32api.keybd_event(win32con.VK_RETURN, 0, 0, 0)
            time.sleep(0.1)
            win32api.keybd_event(win32con.VK_RETURN, 0, win32con.KEYEVENTF_KEYUP, 0)
            
            # 记录命令到日志
            self.logger.log_command(command)
            
            return True, "命令已注入"
        except Exception as e:
            return False, f"注入命令失败: {str(e)}" 